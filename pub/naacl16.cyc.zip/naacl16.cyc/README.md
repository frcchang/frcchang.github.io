[Dev Set]
gs_dev_text: 200 tweets
gs_dev_label: human annotated labels

[Test Set]
gs_test_text: 800 tweets
gs_test_label: human annotated labels

[Other]
unlabeled_text: 127800 unlabeled tweets for training

