This is the data file for ACL2013. We can refer to "http://sourceforge.net/projects/zpar/, version 0.6" for tools

Annotation tools available https://github.com/zhangmeishan/wordstructures for turning CTB trees into word structure format

Thanks for your interest in our work.
